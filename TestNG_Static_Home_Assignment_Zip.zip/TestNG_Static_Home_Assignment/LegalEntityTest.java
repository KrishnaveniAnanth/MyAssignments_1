package assignments;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class LegalEntityTest extends ProjectSpecificMethod {

	@Test
	public void legalEntityTest() {
		// Click on the toggle menu button from the left corner
		driver.findElement(By.xpath("//button[@title='App Launcher']")).click();

		// Click View All and click Legal Entities from App Launcher
		driver.findElement(By.xpath("(//button[@class='slds-button'])[2]")).click();
		WebElement legalElement = driver.findElement(By.xpath("//p[text()='Legal Entities']"));
		driver.executeScript("arguments[0].click();", legalElement);

		// Click on New Legal Entity
		driver.findElement(By.xpath("//div[@title='New']")).click();

		// Enter the Company name as 'TestLeaf'
		driver.findElement(By.xpath("//input[@name='CompanyName']")).sendKeys("TestLeaf");

		// Enter Description as 'Salesforces'
		driver.findElement(By.xpath("(//textarea[@class='slds-textarea'])[2]")).sendKeys("Salesforces");

		// Select Status as 'Active'
		WebElement noneElement = driver.findElement(By.xpath("(//span[text()='--None--'])[1]"));
		driver.executeScript("arguments[0].click();", noneElement);
		WebElement ActiveElement = driver.findElement(By.xpath("//span[text()='Active']"));
		driver.executeScript("arguments[0].click();", ActiveElement);

		// Click on Save
		driver.findElement(By.xpath("//button[text()='Save']")).click();

		// Verify the Alert message(Complete this field)
		boolean alertdisplayed = driver.findElement(By.xpath("(//div[@class='slds-form-element__help'])[1]"))
				.isDisplayed();
		if (alertdisplayed) {
			System.out.println("Alert displayed");
		}

	}

}
